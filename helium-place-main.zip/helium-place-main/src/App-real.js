import React from "react";
import HeliumPlace from "./components/HeliumPlace/HeliumPlace";
import "./index.scss";

const App = () => {
  return (
    <div className="App">
      <HeliumPlace/>
    </div>
  );
};

export default App;