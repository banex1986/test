import { SidebarControls } from './SidebarControls'

export default SidebarControls;