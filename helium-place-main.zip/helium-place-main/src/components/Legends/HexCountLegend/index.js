import { HexCountLegend } from './HexCountLegend'

export default HexCountLegend;