import { Legend } from './Legend'

export default Legend;