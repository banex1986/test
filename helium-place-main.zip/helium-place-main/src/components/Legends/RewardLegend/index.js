import { RewardLegend } from './RewardLegend';

export default RewardLegend