import { HotspotInfo } from './HotspotInfo';

export default HotspotInfo;